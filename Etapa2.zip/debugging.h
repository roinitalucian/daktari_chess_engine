#ifndef DEBUGGING_H
#define DEBUGGING_H

#include <fstream>

void print_board(int board[12][12], std::ofstream& f);
void print_board_d(int board[12][12]);

#endif